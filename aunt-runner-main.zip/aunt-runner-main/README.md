git add index.html
git commit -m "Добавлен HTML-файл"
git push
